Cheeseboard Pixel Pack
=======================

This pack contains 16 pixel art sprites representing various antipasto and cheeseboard items. Each item has 4 frames (64x64px) suitable for subtle animations or idle effects.

Contents:
- 16 sprite sheets (each 4 frames, 64x64px per frame)
- Empty wooden board image for placing items
- Preview image

Format:
- PNG files
- Transparent backgrounds

Usage:
These assets are free to use in personal, commercial, or hobby projects.
No credit required — but a donation or shoutout is always appreciated!

Made with love for game devs, artists, and food lovers.

Enjoy!